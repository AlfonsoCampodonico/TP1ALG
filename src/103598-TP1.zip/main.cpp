#include  "main.h"
int main() {
    iniciarJuego();
    return 0;
}
