#pragma once
#ifndef MAIN_H_
#define MAIN_H_
#include  "JuegoDeLaVida.h"
#endif // MAIN_H_ 
